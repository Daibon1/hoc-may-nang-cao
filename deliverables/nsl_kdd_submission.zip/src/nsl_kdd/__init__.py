"""NSL-KDD anomaly detection."""
